####################################
### SEARCHES 248 CEGs ON A FASTA ###
####################################

##############################################
####### CHECK THAT THE hmm/ DIRECTORY #######
#### AND THE completeness_cutoff.tbl file ####
##### ARE ON PRESENT WORKING DIRECTORY #####
##############################################

# arguments: fasta file, name of the directory that will be created with all HMMs searches, path to hmmer suite (http://hmmer.org/), path to transeq binary (part of EMBOSS suite: http://emboss.sourceforge.net/download/)

# running example: python2 ceg.py transcripts.fasta organism_CEGs tools/hmmer-3.1b1 tools/EMBOSS-6.6.0/emboss/transeq

import re
import os
import sys

def open_file(x):           # opens a file given as an absolute or relative path
    a=open(x).read().splitlines()
    return a

def filtro(a,c):
    l=[i for i in a if i[-1]>c]
    return l

def CEGs_contigs(x):
    a=[re.split('\t',i)[0] for i in open_file(x)]
    return a

def cegs(x):
    a=[re.split('\t',i)[1] for i in open_file(x)]
    return a

fasta=sys.argv[1]
dire=sys.argv[2]
hammer=sys.argv[3]
transeq=sys.argv[4]

hmms=os.popen('ls hmms/').read().splitlines()

os.system('mkdir %s' % dire)

pep=dire+'/query_six_frames.pep'

os.system(transeq+' '+fasta+' '+pep+' -frame=6')

for i in hmms:
    print(i[:-4]+'\t'+str((float(hmms.index(i))/len(hmms))*100)+'%')
    tblout=dire+'/'+i[:-4]+'_out.tbl'
    searchout=dire+'/'+i[:-4]+'_search.out'
    os.system(hammer+'/binaries/hmmsearch --tblout %s hmms/%s %s > %s' % (tblout,i,pep,searchout))
    
l=os.popen('ls %s/*_out.tbl' % dire).read().splitlines()
a=[[] for i in range(len(l))]

for i in l:
    b=[re.split(' +',x) for x in os.popen('grep -v "#" %s' % i).read().splitlines()]
    bb=[[z[0],z[2],float(z[4]),float(z[5])] for z in b]
    a[l.index(i)]=bb

c=[re.split(' +',i) for i in open_file('completeness_cutoff.tbl')]
cc=[[i[0],float(i[2])] for i in c]

aa=[filtro(i,cc[a.index(i)][1]) for i in a]
aaa=[i[0][0] for i in aa if len(i)>0]
aac=[i[0][0]+'\t'+i[0][1] for i in aa if len(i)>0]

with open(dire+'_names','a') as file:
    for i in aaa:
        print >> file, i

with open(dire+'_names_CEG','a') as file:
    for i in aac:
        print >> file, i






