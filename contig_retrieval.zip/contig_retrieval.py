###### MIT License ######

###### Copyright (c) 2018 Maximiliano Estravis ######


# coding=utf-8

# arguments: search type (uniprot, tair, contig, gene_name, go_term, go_number), list of search queries (in a separate file, delimited by new lines), and sample (the four assemblies of this work: ZT48_20C, ZT60_20C, ZT48_34C, ZT60_34C)

# running example: python2 contig_retrieval.py uniprot test.list ZT48_20C > test_search.txt	# where test.list is the file included in this directory

import sys
import re

tipo=sys.argv[1]
lista=sys.argv[2]
sample=sys.argv[3]

def name(o):
    s=open(o).read()
    names=re.findall(">.+\n",s)
    short=[re.sub('>','',re.split("_",i)[0])+"_"+re.split("_",i)[1] for i in names]
    leng=[re.split("_",i)[3] for i in names]
    cov=[re.split("_",i)[5] for i in names]
    n=[[short[i],leng[i],cov[i]] for i in range(len(names))]
    return n

def seq(o):
    s=open(o).read()
    seqs=re.split(">.+\n",s)
    seqs.pop(0)
    return seqs

def go(l):
    go=[]
    for i in l:
        aa=i[9:-1]
        aaa=[aa[x:x+3] for x in range(0,len(aa),3)]
        go.append(aaa)
    return go

def info(l):
    print('### Search type: %s ###\n' % tipo)
    print('###### Search assembly: %s ######\n' % sample)
    print('Search items:\n')
    for i in l:
        print i 

def imprimir(l,z):
    for i in l:
        print('\n\n### New item: %s ###\n\n' % i)
        for j in anot_2:
            if i==j[z]:
                h=anot_2.index(j)            
                print('CONTIG:\n\t%s\nFRAME:\n\t%s\nLONG:\n\t%s\nCOVERAGE:\n\t%s\nSCORE:\n\t%s\nUNIPROT:\n\t%s\nTAIR:\n\t%s\nNAME:\n\t%s\nGO:' % (anot_2[h][0],anot_2[h][1],anot_2[h][2],anot_2[h][3],anot_2[h][4],anot_2[h][5],anot_2[h][8],anot_2[h][7]))    ## General Info
                for x in goo[h]:
                    print('\t%s' % (x))     ## GO terms
                print('SEQ:\n%sORF:\n%s' % (seqs[int(anot_2[h][-1])],seqsp[h]))      ## nt and aa sequences
                print "#\n"

def imprimir_go(l,z):
    for i in l:
        print('\n\n### New item: %s ###\n\n' % i)
        for j in go:
            for m in j:
                if i==m[z]:
                    h=go.index(j)            
                    print('CONTIG:\n\t%s\nFRAME:\n\t%s\nLONG:\n\t%s\nCOVERAGE:\n\t%s\nSCORE:\n\t%s\nUNIPROT:\n\t%s\nTAIR:\n\t%s\nNAME:\n\t%s\nGO:' % (anot_2[h][0],anot_2[h][1],anot_2[h][2],anot_2[h][3],anot_2[h][4],anot_2[h][5],anot_2[h][8],anot_2[h][7]))    ## General Info
                    for x in goo[h]:
                        print('\t%s' % (x))     ## GO terms
                    print('SEQ:\n%sORF:\n%s' % (seqs[int(anot_2[h][-1])],seqsp[h]))      ## nt and aa sequences
                    print "#\n"


l=open(lista).read().splitlines()
names=name('%s.fasta' % sample)
seqs=seq('%s.fasta' % sample)

namesp=name('%s.pep' % sample)
seqsp=seq('%s.pep' % sample)

anot_1=[re.split('\t',i) for i in open('%s_anot_GO_t' % sample).read().splitlines()]

go=go(anot_1)
goo=[['\t'.join(i) for i in j] for j in go]

anot_2=[[i[0],i[1],i[2],i[3],i[4],i[5],i[6],i[7],i[8],i[-1]] for i in anot_1]

info(l)     ## prints this search's info

if tipo=='uniprot':
    imprimir(l,5)
elif tipo=='tair':
    imprimir(l,8)
elif tipo=='contig':
    imprimir(l,0)
elif tipo=='gene_name':
    imprimir(l,7)
elif tipo=='go_term':
    imprimir_go(l,0)
elif tipo=='go_number':
    imprimir_go(l,1)
else:
	print "Allowed types are:\n\tuniprot: Uniprot IDs (e.g. Q0WV96, O24457)\n\ttair: TAIR IDs (e.g. AT1G01010, AT5G67530)\n\tcontig: contig name from the subject assembly (e.g. NODE_77678, chain_7)\n\tgene_name: gene descriptor (e.g. bZIP transcription factor 49, photosystem II oxygen evolving complex)\n\tgo_term: Gene Ontology textual term (e.g. response to cytokinin, extracellular region)\n\tgo_number: Gene Ontology numeric term (e.g. GO:0004371, GO:0046872)"
