######## MAKE SURE THAT THE SCRIPTS/ DIRECTORY IS ########
########## IN THE SAME DIRECTORY AS THIS SCRIPT ##########

# coding=utf-8

import os
import re

def error(s):
    if e != 0:
        print('\n\n\t\t'+s+'\n\n')
        quit()

ini_file = [re.split('=',i)[1] for i in open('lenga.ini').read().splitlines() if len(i)>0 and i[0]!=';']   # reads the .ini file and returns the paths to the programs used by the pipeline, as strings

exper = ini_file[0]
reads = ini_file[1]
trimm = ini_file[2]
fastx = ini_file[3]
spades = ini_file[4]
blat = ini_file[5]
exonerate = ini_file[6]
star = ini_file[7]
transeq = ini_file[8]

print("\n\n\t\tBEGINNING WORK %s\n\n" % exper)

os.system('mkdir %s' % exper)
os.chdir(exper)

#####################################################
################ ASSEMBLY CORRECTION ################
#####################################################

######## first trimming
######## feel free to change parameters and check how read quality improves using FastQC (https://www.bioinformatics.babraham.ac.uk/projects/fastqc/)
reads_trim = re.split('/',reads)[-1][:-5] + 'trim.fastq'
e = os.system('java -jar %s SE -phred33 %s %s LEADING:3 TRAILING:3 SLIDINGWINDOW:5:15 MINLEN:36' % (trimm, reads, reads_trim))
error("ERROR IN FIRST TRIMMING")

print("\n\n\t\tFIRST TRIMMED FILE: %s\n\n" % reads_trim)

####### second (and definite) trimming
####### if you should like to keep the first trimmed reads as the definite ones, uncomment the following line and comment the next three
#reads_trimDef = reads_trim
reads_trimDef = reads_trim[:-6] + 'Def.fastq'
e = os.system('%s/fastx_trimmer -Q33 -l 250 -i %s -o %s' % (fastx, reads_trim, reads_trimDef))
error("ERROR IN DEFINITE TRIMMING")

print("\n\n\t\tDEFINITE TRIMMED FILE: %s\n\n" % reads_trimDef)

###### de novo assembly
###### feel free to change parameters according to your sequencing chemistry and computational resources
os.system('mkdir assembly')
e = os.system('%s --iontorrent -m 64 -t 20 -k67 -s %s --ss-fr -o assembly/' % (spades, reads_trimDef))
error("ERROR IN ASSEMBLY")

print("\n\n\t\tDE NOVO ASSEMBLY: assembly/transcripts.fasta\n\n")

os.system('mkdir interm_files')      # creates a directory to keep intermediate files produced during assembly correction
os.system('cp assembly/transcripts.fasta interm_files/')
os.chdir('interm_files')

###### contig merging
###### generates 5 intermediate files: 
# 1) the reverse complement of all contigs (.fasta.rev)
# 2) all contigs, in both forward and reverse orientations (.fasta.fwd-rev)
# 3) a blat of 2) against itself (.fasta.fwd-rev.self.psl)
# 4) chain info file, containing which contigs were merged to produce each chain (.fasta.chains_info)
# 5) chain fasta file (.fasta.chains)
e= os.system('php ../../scripts/chains.php transcripts.fasta %s %s' % (exonerate, blat))
error("ERROR IN CONTIG MERGING")

print("\n\n\t\tCONTIG MERGING DONE\n\n")

###### filtering
###### removes contigs used for chain generation, and keeps only chains and contigs longer than X nt
###### generates two intermediate files:
# 6) length-filtered chains (.fasta.chains.filter)
# 7) length-filtered contigs not used in chains (.fasta.filter)
X = "200"
e = os.system('php ../../scripts/filter_chains.php %s transcripts.fasta.chains_info transcripts.fasta.chains transcripts.fasta' % X)
error("ERROR IN CHAIN AND CONTIG FILTERING")

print("\n\n\t\tCHAIN AND CONTIG FILTERING DONE\n\n")

##### first redundancy filtering
##### generates two intermediate files:
# 8) a blat of 6) against itself (.fasta.chains.filter.self.psl)
# 9) redundancy-filtered chains (.fasta.chains.filter.red1)
e = os.system('php ../../scripts/eliminate_revcomp.php transcripts.fasta.chains.filter %s' % blat)
error("ERROR IN FIRST REDUNDANCY FILTERING")

print("\n\n\t\tFIRST REDUNDANCY FILTERING DONE\n\n")

##### reunite chains and contigs
##### generates one intermediate file:
# 10) length-filtered contigs not used in chains (file 7) and length- and redundancy-filtered chains (file 9) (.step01.fasta)
os.system('cat transcripts.fasta.chains.filter.red1 > transcripts.step01.fasta')
os.system('cat transcripts.fasta.filter >> transcripts.step01.fasta')

##### self-blat to eliminate further redundancy
##### generates one intermediate file:
# 11) a blat of 10) against itself (.step01.fasta.self.psl)
os.system('%s -maxIntron=0 -noHead -maxGap=0 -minScore=61 transcripts.step01.fasta transcripts.step01.fasta transcripts.step01.fasta.self.psl' % blat)

#### second redundancy filtering
#### OVL defines the minimum nt length evaluated to filter (in our case, the chosen k-mer size for assembly)
#### PERC defines the minimum overlap to filter 
#### generates one intermediate file:
# 12) redundancy filtered chains and contigs (.step02.fasta)
OVL = "67"
PERC = "0.80"
os.system('php ../../scripts/eliminate_redundant_fasta.php %s %s transcripts.step01.fasta transcripts.step01.fasta.self.psl > transcripts.step02.fasta' % (OVL, PERC))
error("ERROR IN SECOND REDUNDANCY FILTERING")

print("\n\n\t\tSECOND REDUNDANCY FILTERING DONE\n\n")

##### STRAND CORRECTING #####

os.chdir('..')
os.system('cp interm_files/transcripts.step02.fasta .')
os.system('mkdir %s_idx' % exper)

##### index with STAR
##### feel free to change genomeSAindexNbase according to your transcriptome size
e = os.system('%s --runMode genomeGenerate --genomeSAindexNbases 11 --genomeDir %s_idx --genomeFastaFiles transcripts.step02.fasta' % (star, exper))
error("ERROR IN TRANSCRIPTOME INDEXING")

print("\n\n\t\tINDEXING DONE\n\n")

#### read mapping
#### feel free to change STAR parameters according to your computational resources and dataset
os.system('mkdir %s_map' % exper)
e = os.system('%s --genomeDir %s_idx --readFilesIn %s --runThreadN 20 --outFileNamePrefix %s_map/%s_map_ --alignIntronMax 21' % (star, exper, reads_trimDef, exper, exper))
error("ERROR IN READ MAPPING")

print("\n\n\t\tREAD MAPPING DONE\n\n")

#### strand fetching
#### creates a table with every chain/contig and its reads mapping in one sense and the other
e = os.system('php ../scripts/SAM_tx-strand_inspector.php %s_map/%s_map_Aligned.out.sam > %s_map/%s_map_Aligned.strand' % (exper, exper, exper, exper))
error("ERROR IN STRAND FETCHING")

print("\n\n\t\tSTRAND FETCHING DONE\n\n")

#### strand correction
#### before this point you should manually inspect a set of GOI to find whether your transcripts are oriented forward or backwards
sense = "F"
e = os.system('php ../scripts/correct_seq_strands.php %s transcripts.step02.fasta %s_map/%s_map_Aligned.strand > transcripts.step02.fasta.strand_corrected.tbl' % (sense, exper, exper))
error("ERROR IN STRAND CORRECTION")

print("\n\n\t\tSTRAND CORRECTION DONE\n\n")

#### creates a score file according to mapped reads orientation
e = os.system('''awk 'BEGIN{OFS="\t"} {s=$2+$3; if($2>$3) {r=($2+1)/(s+2)} else {r=($3+1)/(s+2)}; print $1,$2,$3,s,r; }' %s_map/%s_map_Aligned.strand > %s_map/%s_map_Aligned.strand.scr''' % (exper, exper, exper, exper))
error("ERROR IN SCORE ASSIGNMENT")

print("\n\n\t\tSCORE ASSIGNMENT DONE\n\n")

#### discards every contig that does not have >95% of its mapped reads in the same strand
e = os.system("awk '{if($5 < 0.95) print}' %s_map/%s_map_Aligned.strand.scr > %s_map/%s_map_Aligned.strand.scr_50-95" % (exper, exper, exper, exper))
error("ERROR IN ASSYMETRIC CONTIGS DISCARD")

print("\n\n\t\tASSYMETRIC CONTIGS DISCARD DONE\n\n")

#### filters the unwanted transcripts and generates the final file (.step03.fasta)
e = os.system("python ../scripts/filter_fasta.py transcripts.step02.fasta.strand_corrected %s_map/%s_map_Aligned.strand.scr_50-95 transcripts.step03.fasta" % (exper, exper))
error("ERROR IN FINAL FILTERING")

print("\n\n\t\tFINAL FILTERING DONE: %s/transcripts.step03.fasta\n\n" % exper)

#####################################################
#################### ANNOTATION #####################
#####################################################

#### annotates the corrected assembly against the Arabidopsis thaliana proteome (http://www.uniprot.org/proteomes/UP000006548)
#### generates intermediate files in annotation/
os.system('mkdir annotation')
os.system('cp transcripts.step03.fasta ../ids_atha.tbl ../go_atha_short ../Arab_uniprot-proteome.fasta annotation/')
os.chdir('annotation/')

e = os.system('python ../../scripts/annotation.py transcripts.step03.fasta  Arab_uniprot-proteome.fasta %s %s ../../scripts/merge_psl_by_query.php' % (blat, transeq))







