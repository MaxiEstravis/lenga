#!/usr/local/bin/php
<?php
ini_set('memory_limit', '60G');

$prg  = array_shift($argv);

$aln = array();

if(count($argv)==0 || ($argv[0] == '-h' || $argv[0] == '--help')) error("

Reference Tables:

Mandatory SAM/BAM fields
See: http://samtools.sourceforge.net/SAM1.pdf
--------------------------------------------------------------------------------
Field  Descriptions
================================================================================
qname  Query (pair) NAME
flag   bitwise FLAG
rname  Reference sequence NAME
pos    1-based leftmost POSition/coordinate of clipped sequence
map    QMAPping Quality (Phred-scaled)
cigar  extended CIGAR string
mrnm   Mate Reference sequence NaMe (\342\200\230=\342\200\231 if same as RNAME)
mpos   1-based Mate POSistion
isize  Inferred insert SIZE
seq    query SEQuence on the same strand as the reference
qual   query QUALity (ASCII-33 gives the Phred base quality)
opt    variable OPTional fields in the format TAG:VTYPE:VALUE

Bitwise Flags
See http://picard.sourceforge.net/explain-flags.html
    http://bio-bwa.sourceforge.net/bwa.shtml

--------------------------------------------------------------------------------
Flag	Dec	Name            Description
================================================================================
0x0001	1	PAIRED		the read is paired in sequencing
0x0002	2	PAIR_MAPPED	the read is mapped in a proper pair
0x0004	4	UNMAPPED	the query sequence itself is unmapped
0x0008	8	MATE_UNMAPPED	the mate is unmapped
0x0010	16	REVERSE		strand of the query (1 when SEQ was reversed in SAM file)
0x0020	32	MATE_REVERSE	strand of the mate
0x0040	64	FIRST_READ	the read is the first read in a pair
0x0080	128	SECOND_READ	the read is the second read in a pair
0x0100	256	NOT_PRIMARY	the alignment is not primary
0x0200	512	FAILS		the read fails platform/vendor quality checks
0x0400	1024	DUPLICATE	the read is either a PCR or an optical duplicate

view :

http://bio-bwa.sourceforge.net/bwa.shtml
http://samtools.sourceforge.net/SAM1.pdf
    
Bit 0x10 indicates whether SEQ has been reverse complemented and QUAL
reversed. When bit 0x4 is unset, this corresponds to the strand to which the segment has been mapped.  When 0x4 is set,
this indicates whether the unmapped read is stored in its original orientation as it came o the
sequencing machine

--------------------------------------------------------------------------------
Tag	Meaning
================================================================================
NM	Edit distance
MD	Mismatching positions/bases
AS	Alignment score
BC	Barcode sequence
X0	Number of best hits
X1	Number of suboptimal hits found by BWA
XN	Number of ambiguous bases in the referenece
XM	Number of mismatches in the alignment
XO	Number of gap opens
XG	Number of gap extentions
XT	Type: Unique/Repeat/N/Mate-sw
XA	Alternative hits; format: (chr,pos,CIGAR,NM;)*
XS	Suboptimal alignment score
XF	Support from forward/reverse alignment
XE	Number of supporting seeds

",'e');

$strmap =array();

$add=250000;
$c = 0;
$sams = array();
while(count($argv)>0) {
  $n = 0; $nc = $add;
  $sam  = array_shift($argv);
  $sams[$c] = $sam;
  $buf = fopen($sam,"r");
  if(!$buf) error("[$sam] not found\n",'e');
  $sz = filesize($sam);
  error("Loading $sam size=".format_bytes($sz)." ...",'i');
  $l = fgets($buf);
  while (!feof($buf)) {
    if($l[0]!='@') {
      $n++;
      $a = preg_split("/\t/",$l);
      $qname  = substr($a[0],22);
      $flag   = $a[1]; /// bitwise FLAG
      $rname  = $a[2]; /// Reference sequence NAME
      $pos    = $a[3]; /// 1-based leftmost POSition/coordinate of clipped sequence
      $map    = $a[4]; ///  QMAPping Quality (Phred-scaled)
      $cigar  = $a[5]; /// CIGAR
      $seq  = $a[9]; /// query SEQuence on the same strand as the reference
      
      if(($flag & 0x0010)>0) $str='-';
      else $str = '+';
      
      if(!isset($strmap[$rname])) {
		$strmap[$rname]=array();
		$strmap[$rname]['+']=0;
		$strmap[$rname]['-']=0;
		}
      $strmap[$rname][$str]++;
      }
    $l = fgets($buf);
    }
  fclose($buf);
  $c++;
  }

foreach($strmap as $rname => $a) {
  print "$rname\t".$a['+']."\t".$a['-']."\n";
  }

error("Processing mapped reads...",'i');  
$paired = 0;
$unpaired = array();
$unpaired[0] = 0;
$unpaired[1] = 0;

$diff_ctg=0;
$same_ctg=0;

$sense = array();
$sense['S'] = array(); /// same 
$sense['C'] = array(); /// convergent 
$sense['D'] = array(); /// divergent

if(isset($sams[1])) $nam = basename($sams[0])."--".basename($sams[1]);
else $nam = basename($sams[0]);

$fo = array();
$fo['S'] = fopen("$nam.SAM_paired_inspector_Sense.tbl",'w');  
$fo['C'] = fopen("$nam.SAM_paired_inspector_Convergent.tbl",'w');  
$fo['D'] = fopen("$nam.SAM_paired_inspector_Divergent.tbl",'w');  

$mult=array();

foreach($aln as $r => $a) {
  if(!isset($mult[$r])) {
    if(count($a)>1) {
      $paired++;
      
      $r1 = preg_split("/\#/",$a[0]);
      $r2 = preg_split("/\#/",$a[1]);
      
      if($r1[0]!=$r2[0]) $diff_ctg++;
      else {
		$same_ctg++;
		/// distance
		$p = "";
		if($r1[2] == $r2[2]) $p='S'; /// Same sense 
		if($r1[1]<$r2[1]) {
		  $d = ($r2[1]-$r1[1])+$r2[3];
		  if($r1[2]=='-' && $r2[2]=='+') $p='D';
		  if($r1[2]=='+' && $r2[2]=='-') $p='C';
		  }
		else {
		  $d = ($r1[1]-$r2[1])+$r1[3];
		  if($r2[2]=='-' && $r1[2]=='+') $p='D';
		  if($r2[2]=='+' && $r1[2]=='-') $p='C';
		  }
		$sense[$p][] = $d;  
		fprintf($fo[$p],implode("\t",$r1)."\t".implode("\t",$r2)."\t$p\t$d\n"); 
		}
      }
    else {
      foreach($a as $c => $b) $unpaired[$c]++;
      }
    }
  }

fclose($fo['S']);
fclose($fo['C']);
fclose($fo['D']);

$fos = fopen("$nam.SAM_paired_inspector_Summary.txt",'w');  
   
fprintf($fos,"SAM #1 = ".$sams[0]."\n");  
if(isset($sams[1])) fprintf($fos,"SAM #2 = ".$sams[1]."\n");  
fprintf($fos,"Multiple mapped reads = ".count($mult)."\n");  
fprintf($fos,"Unpaired R1 [0] = ".$unpaired[0]."\n");  
fprintf($fos,"Unpaired R2 [1] = ".$unpaired[1]."\n");  
fprintf($fos,"Both mapped = $paired\n"); 
fprintf($fos,"   @ diff contigs = $diff_ctg \n"); 
fprintf($fos,"   @ same contigs = $same_ctg \n"); 
fprintf($fos,"      Same direction = ".count($sense['S'])."\n"); 
fprintf($fos,"      Convergent direction = ".count($sense['C'])."\n"); 
fprintf($fos,"      Divergent direction = ".count($sense['D'])."\n"); 
fclose($fos);

error("Summary file: $nam.SAM_paired_inspector_Summary.txt",'i');  
error("Same direction table: $nam.SAM_paired_inspector_Sense.tbl",'i');  
error("Covergent direction table: $nam.SAM_paired_inspector_Convergent.tbl",'i');  
error("Divergent direction table: $nam.SAM_paired_inspector_Divergent.tbl",'i');  

die;

////////////////////////////////////////////////////////////
function error($l,$d){
  switch($d) {
    case 'W':
    case 'w':
      fprintf(STDERR,"WARNING: $l\n");
      break;
    case 'E':
    case 'e':
      fprintf(STDERR,"ERROR: $l\n");
      die;
      break;
    case 'I':
    case 'i':
      fprintf(STDERR,"# $l\n");
      break;
    default:
      break;
    }
  }

////////////////////////////////////////////////////////////
function format_bytes($size) {
 $unit=array('B','KB','MB','GB','TB','PB');
 return @round($size/pow(1024,($i=floor(log($size,1024)))),2).' '.$unit[$i];
 }

