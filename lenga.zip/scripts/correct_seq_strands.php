#!/usr/local/bin/php
<?php
ini_set('memory_limit', '3G');

$prg  = array_shift($argv);

$sense  = array_shift($argv); # F or R

$fst  = array_shift($argv);
$seqs = readFasta($fst);
error(count($seqs)." seqs read from $fst",'i');

foreach($seqs as $k => $s) {
  $sk[$k] = array();
  $sk[$k]['len'] = strlen($s);
  $sk[$k]['F'] = 0;
  $sk[$k]['R'] = 0;
  }

while(count($argv)>0) {
  $file = array_shift($argv);
  error("loading stranded read counts from $file ...",'i');
  $fi = file($file);
  foreach($fi as $l) {
    $l = trim($l);
    $a = preg_split("/\t/",$l);  // print_r($a);
    $k = $a[0];
    if(isset($sk[$k])) {
      //print "$l\n";      
      $sk[$k]['F'] += $a[1];
      $sk[$k]['R'] += $a[2];
      }
    else error("seq id not found in fasta",'w');
    }
  }   

$nvoid=0;
$cc=array(); $cc['F']=0; $cc['R']=0; $cc['U']=0;

$fon = "$fst.strand_corrected";
$fo = fopen($fon,'w');

foreach($sk as $k => $a) {
  $l = $a['len'];
  $t = $a['F']+$a['R'];
  $l2r = log( (($a['F']+1)/($a['R']+1)),2);
  $e = ($t / $l); 
  
  if($l2r>0) $c='F';
  elseif($l2r<0) $c='R';
  else $c = 'U';
 
  print "$k\t".$a['F']."\t".$a['R']."\t$l\t$e\t$l2r\t$c\n";
  $cc[$c]++;
  if($t==0) $nvoid++;
  
  $s = $seqs[$k];
  if( ($sense=='F' && $c=='R') || ($sense=='R' && $c=='F') ) $s = DNAreverse($s);
  fprintf($fo,">$k"."_$c\n".chunk_split($s,100,"\n"));
  }
fclose($fo);

error("corrected fasta: $fon",'i');
error(count($seqs)." total seqs, $nvoid w/o mapping",'i');
error("   [F] = ".$cc['F'],'i');
error("   [R] = ".$cc['R'],'i');
error("   [U] = ".$cc['U']." no strand bias includes w/o mapping" ,'i');

die;

////////////////////////////////////////////////////////////
function error($l,$d){
  switch($d) {
    case 'W':
    case 'w':
      fprintf(STDERR,"WARNING: $l\n");
      break;
    case 'E':
    case 'e':
      fprintf(STDERR,"ERROR: $l\n");
      die;
      break;
    case 'I':
    case 'i':
      fprintf(STDERR,"# $l\n");
      break;
    default:
      break;
    }
  }

////////////////////////////////////////////////////////////
function readFasta($fst){
  $iSeq = array();
  $buf = fopen($fst,"r");
  if(!$buf) error("openning fasta file ($fst)",'e');
  $ID=-1;
  $l = fgets($buf);
  while (!feof($buf)) {
    $l = trim($l);
    if($l != "") {
      if($l[0] != ">") {
		$iSeq[$ID] .= strtoupper($l); 
		}
      else { 
		$ID=substr($l,1);
		$iSeq[$ID] ="";
		}
      }
    $l = fgets($buf);
    }
  fclose($buf);
  return($iSeq);
  }

////////////////////////////////////////////////////////////
function DNAreverse($DNAstr) {

       $DNAstr = str_replace('A','#',$DNAstr);
       $DNAstr = str_replace('T','A',$DNAstr);
       $DNAstr = str_replace('#','T',$DNAstr);
       $DNAstr = str_replace('a','#',$DNAstr);
       $DNAstr = str_replace('t','a',$DNAstr);
       $DNAstr = str_replace('#','t',$DNAstr);

       $DNAstr = str_replace('G','#',$DNAstr);
       $DNAstr = str_replace('C','G',$DNAstr);
       $DNAstr = str_replace('#','C',$DNAstr);
       $DNAstr = str_replace('g','#',$DNAstr);
       $DNAstr = str_replace('c','g',$DNAstr);
       $DNAstr = str_replace('#','c',$DNAstr);

       $DNAstr = str_replace('R','#',$DNAstr);
       $DNAstr = str_replace('Y','R',$DNAstr);
       $DNAstr = str_replace('#','Y',$DNAstr);
       $DNAstr = str_replace('r','#',$DNAstr);
       $DNAstr = str_replace('y','r',$DNAstr);
       $DNAstr = str_replace('#','y',$DNAstr);

       $DNAstr = str_replace('K','#',$DNAstr);
       $DNAstr = str_replace('M','K',$DNAstr);
       $DNAstr = str_replace('#','M',$DNAstr);
       $DNAstr = str_replace('k','#',$DNAstr);
       $DNAstr = str_replace('m','k',$DNAstr);
       $DNAstr = str_replace('#','m',$DNAstr);

       // S <--> S
       // W <--> W

       $DNAstr = strrev($DNAstr);
       return($DNAstr);
       }

