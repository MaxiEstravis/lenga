# coding=utf-8

import sys
import re
import os

def names(o):       # returns a list containing sequences' names
    s = open(o).read()
    names = re.findall(">.+\n",s)
    return names

def sep_seq(o):
	s = open(o).read()
	seqs = re.split(">.+\n",s)
	seqs.pop(0)
	return seqs


fasta_orig = sys.argv[1]
fasta_filt = sys.argv[2]
fasta_new = sys.argv[3]

t=names(fasta_orig)
s=sep_seq(fasta_orig)

a=[re.split('_',i)[0]+'_'+re.split('_',i)[1]+'_' for i in open(fasta_filt).read().splitlines()]

ii=[t.index(i) for i in t for j in a if j in i]

tt=[i for i in t if t.index(i) not in ii]
ss=[i for i in s if s.index(i) not in ii]
f=[]
for i in range(len(tt)):
	f.append(tt[i]+ss[i])

with open(fasta_new,'a') as file:
	for i in f:
		print >> file, i

